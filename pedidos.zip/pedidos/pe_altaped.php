<?php 
   include('config.php');
   session_start();
   var_dump($_POST);
   // Array que contiene una lista con los nombres de los productos para el select (desplegable)
   $productos = listapeliculas($db);

   
if (isset($_POST) && !empty($_POST)) 
{
	if(isset($_POST['agregar'])){
		crearcarrito();
	}else if(isset($_POST['limpiar'])){
		$_SESSION['cesta']=null;

	}else if(isset($_POST['comprar'])){
		$fechahoy=date('Y-m-s h:m:s');

	}
	
	

}


  
   
?>

<html>
   
   <head>
      <title>Welcome </title>
   </head>
   
   <body>
		<h1>Bienvenido <?php echo $_SESSION['login_user']; ?></h1> 
		<!-- INICIO DEL FORMULARIO -->
	<form action="pe_altaped.php" method="post">
		<h1>productos:</h1>
		<div>
			<select name="pelicula">
				<?php forEach ($productos as $nombre) : ?>
					<?php echo '<option>'.  $nombre . '</option>'; ?>
				<?php endforEach; ?>
			</select>
			<label for="cantidad1">Cantidad:</label>
			<input type="number" name="cantidad">
			
			<br>
			
			
		</div>
		<br>
		<div>
			<input type="submit" value="Comprar Pelicula" name="comprar">
			<input type="submit" value="Agregar a la Cesta" name="agregar">
			<input type="submit" value="Limpiar la Cesta" name="limpiar">
		</div>		
	</form>
	<!-- FIN DEL FORMULARIO -->
   </body>
   <?php
   if(isset($_SESSION['cesta']))
   var_dump($_SESSION['cesta']);
 
 ?>
</html>


<?php
function crearcarrito(){
	if (isset($_POST['agregar']) && !empty($_POST['agregar'])) {
	  
	    if (!isset($_SESSION['cesta'])) //aqui pasa la primera vez
		   $_SESSION['cesta']=array(array($_POST['pelicula'],$_POST['cantidad']));
		  
	    else{
			$arrayProducto=array(array($_POST['pelicula'],$_POST['cantidad']));
			$arrayAnterior= $_SESSION['cesta'];
			array_push($arrayAnterior,$arrayProducto);
			$_SESSION['cesta']=$arrayAnterior;
	       
		}
	}

}

function listapeliculas($db) {
	$productos = array();
	/*Extraigo todos los nombres de peliculas:*/
	$sql="SELECT productName FROM products";
	$resultado = mysqli_query($db, $sql);
if($resultado){
	echo "agd";
	while ($fila = mysqli_fetch_assoc($resultado)) {
		$productos[] = $fila["productName"];
	}
}
	return $productos;
}
?>